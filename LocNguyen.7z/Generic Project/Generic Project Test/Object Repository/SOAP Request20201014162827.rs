<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description>SOAP Request Description20201014162827</description>
   <name>SOAP Request20201014162827</name>
   <tag></tag>
   <elementGuidId>42ec70f2-365a-4d92-a643-cc360a5409a1</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent></httpBodyContent>
   <httpBodyType></httpBodyType>
   <httpHeaderProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>SOAPAction</name>
      <type>Main</type>
      <value>http://www.gama-system.com/webservices/GetExchangeRatesByValueXML</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>text/xml; charset=utf-8</value>
   </httpHeaderProperties>
   <katalonVersion>7.7.5</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <restRequestMethod></restRequestMethod>
   <restUrl></restUrl>
   <serviceType>SOAP</serviceType>
   <soapBody>&lt;soapenv:Envelope xmlns:soapenv=&quot;http://schemas.xmlsoap.org/soap/envelope/&quot; xmlns:web=&quot;http://www.gama-system.com/webservices&quot;>
   &lt;soapenv:Header/>
   &lt;soapenv:Body>
      &lt;web:GetExchangeRatesByValueXML>
         &lt;web:strBank>gero et&lt;/web:strBank>
         &lt;web:strCurrency>sonoras imperio&lt;/web:strCurrency>
         &lt;web:dcmLow>1000.00&lt;/web:dcmLow>
         &lt;web:dcmHigh>1000.00&lt;/web:dcmHigh>
         &lt;web:intRank>3&lt;/web:intRank>
      &lt;/web:GetExchangeRatesByValueXML>
   &lt;/soapenv:Body>
&lt;/soapenv:Envelope></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod>SOAP</soapRequestMethod>
   <soapServiceEndpoint>http://webservices.gama-system.com/exchangerates.asmx</soapServiceEndpoint>
   <soapServiceFunction>GetExchangeRatesByValueXML</soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>false</useServiceInfoFromWsdl>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress>http://webservices.gama-system.com/exchangerates.asmx?WSDL</wsdlAddress>
</WebServiceRequestEntity>
