<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description>SOAP Request Description20201014154742</description>
   <name>SOAP Request20201014154742</name>
   <tag></tag>
   <elementGuidId>a3866a1c-2f8a-41ed-ba12-e96bb5f0ed42</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent></httpBodyContent>
   <httpBodyType></httpBodyType>
   <katalonVersion>7.7.5</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <restRequestMethod></restRequestMethod>
   <restUrl></restUrl>
   <serviceType>SOAP</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod>SOAP</soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>false</useServiceInfoFromWsdl>
   <wsdlAddress>http://webservices.gama-system.com/exchangerates.asmx?WSDL</wsdlAddress>
</WebServiceRequestEntity>
