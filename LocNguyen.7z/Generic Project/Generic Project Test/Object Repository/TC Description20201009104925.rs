<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>TC Description20201009104925</description>
   <name>TC Description20201009104925</name>
   <tag></tag>
   <elementGuidId>69f1b784-fa83-4bcc-8f5a-95db20b7c906</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
