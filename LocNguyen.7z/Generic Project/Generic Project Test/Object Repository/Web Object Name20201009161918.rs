<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>TC Description20201009161918</description>
   <name>Web Object Name20201009161918</name>
   <tag></tag>
   <elementGuidId>e833ddc4-c39a-4f00-b61d-3f08119d2256</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
