<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>TC Description20201009105525</description>
   <name>Web Object Name20201009105525</name>
   <tag></tag>
   <elementGuidId>15132d40-8eda-462d-8477-45d258c00550</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
